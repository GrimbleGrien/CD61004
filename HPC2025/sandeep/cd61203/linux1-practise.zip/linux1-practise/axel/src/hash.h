#ifndef AXEL_HASH_H
#include <stddef.h>

uint32_t axel_hash32(const void *, size_t, const uint64_t *);
#endif
